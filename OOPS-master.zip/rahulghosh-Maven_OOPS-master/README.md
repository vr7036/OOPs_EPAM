# rahulghosh-Maven_OOPS
EPAM Task on Maven and OOPS

New Year's gift!<br />
1) The hierarchy of chocolates and sweets!<br />
-->Chocolates:<br />
    *Cadbury<br />
    *Barone<br />
    *Galaxy<br />
-->Sweets:<br />
  *Rasgulla<br />
  *Gulab Jamun<br />
  *Kheer<br />
  *Kajukatli<br />

2) Collected children's gift to define total weight=560.<br />
3) Sort the chocolates in the gift according to there prices.<br />
4) Finding candies in the gift which are of high price.<br />
 
