package com.epam.rahulghosh_maven_OOPS.sweets;

public class Kajukatli extends Sweets {

    public Kajukatli(String name, int price, int weight) {
        super(name, price, weight);
    }
}