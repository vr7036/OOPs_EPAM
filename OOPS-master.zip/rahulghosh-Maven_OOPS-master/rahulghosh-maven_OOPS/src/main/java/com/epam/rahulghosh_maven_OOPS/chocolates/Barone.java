package com.epam.rahulghosh_maven_OOPS.chocolates;

public class Barone extends Chocolate {

    public Barone(String name, int price, int weight) {
        super(name, price, weight);
    }
}