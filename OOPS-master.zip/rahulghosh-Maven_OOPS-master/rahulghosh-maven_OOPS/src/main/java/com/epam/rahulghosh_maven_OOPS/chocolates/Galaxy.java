package com.epam.rahulghosh_maven_OOPS.chocolates;

public class Galaxy extends Chocolate {

    public Galaxy(String name,int price,int weight){
        super(name,price,weight);
    }
}