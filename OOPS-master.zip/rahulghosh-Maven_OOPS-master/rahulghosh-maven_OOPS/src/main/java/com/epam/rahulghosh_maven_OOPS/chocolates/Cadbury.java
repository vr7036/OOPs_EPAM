package com.epam.rahulghosh_maven_OOPS.chocolates;

public class Cadbury extends Chocolate {

    public Cadbury(String name,int price,int weight){
        super(name,price,weight);
    }
}
