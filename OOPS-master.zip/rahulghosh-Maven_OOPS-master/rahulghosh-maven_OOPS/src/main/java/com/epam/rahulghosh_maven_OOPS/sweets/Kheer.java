package com.epam.rahulghosh_maven_OOPS.sweets;

public class Kheer extends Sweets {

    public Kheer(String name, int price, int weight) {
        super(name, price, weight);
    }
}
